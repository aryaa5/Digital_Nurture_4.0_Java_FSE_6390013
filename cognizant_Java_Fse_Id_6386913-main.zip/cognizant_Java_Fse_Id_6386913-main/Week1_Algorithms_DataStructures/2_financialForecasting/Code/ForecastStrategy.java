public interface ForecastStrategy {
    double calculate(ForecastRequest request);
}
