public interface ProductFactory {
    Product createProduct(String id, String name, int quantity, double price);
}
