public class StripeGateway {
    public void pay(double amountInDollars) {
        System.out.println("Payment of Rs. " + amountInDollars + " made through Stripe.");
    }
}
